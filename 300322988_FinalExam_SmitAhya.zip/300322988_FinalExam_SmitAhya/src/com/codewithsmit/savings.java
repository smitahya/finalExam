/*
 * Created by JFormDesigner on Sat Aug 08 09:03:09 PDT 2020
 */

package com.codewithsmit;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import net.miginfocom.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.Vector;

/**
 * @author Smit Ahya
 */


public class savings extends JFrame {

    public String CustomerNoTemp;

    public savings() {
        initComponents();
    }

    public savings(String customerName, String typeofSavings, int customerNo, int noOfYears, double initialDeposit) {

    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - Smit Ahya
        label1 = new JLabel();
        numField = new JTextField();
        label2 = new JLabel();
        nameField = new JTextField();
        label3 = new JLabel();
        depositField = new JTextField();
        label4 = new JLabel();
        yesrField = new JTextField();
        label5 = new JLabel();
        comboBox = new JComboBox<>();
        scrollPane1 = new JScrollPane();
        table1 = new JTable();
        scrollPane2 = new JScrollPane();
        table2 = new JTable();
        addbtn = new JButton();
        editbtn = new JButton();
        delbtn = new JButton();

        //======== this ========
        var contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "hidemode 3",
            // columns
            "[fill]" +
            "[fill]",
            // rows
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]"));

        //---- label1 ----
        label1.setText("Enter the Customer Number");
        contentPane.add(label1, "cell 0 0");

        //---- numField ----
        numField.setColumns(20);
        contentPane.add(numField, "cell 1 0");

        //---- label2 ----
        label2.setText("Enter the Cutomer Name");
        contentPane.add(label2, "cell 0 1");

        //---- nameField ----
        nameField.setColumns(20);
        contentPane.add(nameField, "cell 1 1");

        //---- label3 ----
        label3.setText("Enter the Initial Deposit");
        contentPane.add(label3, "cell 0 2");

        //---- depositField ----
        depositField.setColumns(20);
        contentPane.add(depositField, "cell 1 2");

        //---- label4 ----
        label4.setText("Enter the Number of Years");
        contentPane.add(label4, "cell 0 3");

        //---- yesrField ----
        yesrField.setColumns(20);
        contentPane.add(yesrField, "cell 1 3");

        //---- label5 ----
        label5.setText("Choose the type of Savings ");
        contentPane.add(label5, "cell 0 4");

        //---- comboBox ----
        comboBox.setModel(new DefaultComboBoxModel<>(new String[] {
            "Savings-Deluxe",
            "Savings-Regular"
        }));
        contentPane.add(comboBox, "cell 1 4");

        //======== scrollPane1 ========
        {
            scrollPane1.setViewportView(table1);
        }
        contentPane.add(scrollPane1, "cell 0 5");

        //======== scrollPane2 ========
        {
            scrollPane2.setViewportView(table2);
        }
        contentPane.add(scrollPane2, "cell 1 5");

        //---- addbtn ----
        addbtn.setText("Add");
        addbtn.addActionListener(e -> {
            try {
                addbtnActionPerformed(e);
            } catch (ClassNotFoundException classNotFoundException) {
                classNotFoundException.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        contentPane.add(addbtn, "cell 0 6");

        //---- editbtn ----
        editbtn.setText("Edit");
        contentPane.add(editbtn, "cell 0 6");

        //---- delbtn ----
        delbtn.setText("Delete");
        contentPane.add(delbtn, "cell 0 6");
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - Smit Ahya
    private JLabel label1;
    private JTextField numField;
    private JLabel label2;
    private JTextField nameField;
    private JLabel label3;
    private JTextField depositField;
    private JLabel label4;
    private JTextField yesrField;
    private JLabel label5;
    private JComboBox<String> comboBox;
    private JScrollPane scrollPane1;
    private JTable table1;
    private JScrollPane scrollPane2;
    private JTable table2;
    private JButton addbtn;
    private JButton editbtn;
    private JButton delbtn;
    // JFormDesigner - End of variables declaration  //GEN-END:variables

    PreparedStatement insert;

    public void updatetable() throws ClassNotFoundException, SQLException {
        int c;
        //load sql query
        Class.forName("com.mysql.jdbc.Driver");

        //create connection
        Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/savings","root","");
        insert = con1.prepareStatement("Select * from savingstable");
        ResultSet rs = insert.executeQuery();
        ResultSetMetaData Res = rs.getMetaData();
        c = Res.getColumnCount();
        DefaultTableModel df = (DefaultTableModel) table1.getModel();
        df.setRowCount(0);
        while(rs.next()) {
            Vector v2 = new Vector();
            for(int a=1;a<=c;a++){
                v2.add(rs.getString("custno"));
                v2.add(rs.getString("custname"));
                v2.add(rs.getString("cdep"));
                v2.add(rs.getString("nyears"));
                v2.add(rs.getString("savtype"));

            }
            df.addRow(v2);
        }
    }

    private void addbtnActionPerformed(ActionEvent e) throws ClassNotFoundException, SQLException {
        String number, name, type;
        double deposit, years;
        number = numField.getText();
        name = nameField.getText();
        deposit = Double.valueOf(depositField.getText());
        years = Double.valueOf(yesrField.getText());
        type = comboBox.getSelectedItem().toString();


        //load sql query
        Class.forName("com.mysql.jdbc.Driver");

        //create connection
        Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/savings","root","");

        if(e.getSource()==addbtn) {
            insert = con1.prepareStatement("Select * from savingstable where custno = ?");
            insert.setString(1, number);
            ResultSet rs = insert.executeQuery();
            if(rs.isBeforeFirst()){          //res.isBeforeFirst() is true if the cursor
                JOptionPane.showMessageDialog(null,"The CustNo you are trying to enter already exists ");
                numField.setText("");
                nameField.setText("");
                depositField.setText("");
                yesrField.setText("");
                comboBox.setToolTipText("");

                numField.requestFocus();
                return;
            }
            insert = con1.prepareStatement("insert into savingstable values(?,?,?,?,?)");
            insert.setString(1, number);
            insert.setString(2, name);
            insert.setDouble(3, deposit);
            insert.setDouble(4, years);
            insert.setString(5, type);

            insert.executeUpdate();
            JOptionPane.showMessageDialog(null, "Record added");
            numField.setText("");
            nameField.setText("");
            depositField.setText("");
            yesrField.setText("");
            comboBox.setToolTipText("");

            numField.requestFocus();
            updatetable();
        }

    }

    private void table1MouseClicked(MouseEvent e) {
        // TODO add your code here

        DefaultTableModel df = (DefaultTableModel)table1.getModel();
        int index1 = table1.getSelectedRow();
        numField.setText(df.getValueAt(index1,0).toString());
        CustomerNoTemp = numField.getText();
        nameField.setText(df.getValueAt(index1,1).toString());
        depositField.setText(df.getValueAt(index1,2).toString());
        yesrField.setText(df.getValueAt(index1,3).toString());

    }



    public void model(){
        String[] cols = {"Number", "Name","Deposit","Years","Type of Savings"};
        String[][] data = {{"d1", "d1.1"},{"d2", "d2.1"},{"d3", "d3.1"},{"d4", "d4.1"},{"d5", "d5.1"}};
        DefaultTableModel model = new DefaultTableModel(data, cols);
        table1.setModel(model);
    }




}
