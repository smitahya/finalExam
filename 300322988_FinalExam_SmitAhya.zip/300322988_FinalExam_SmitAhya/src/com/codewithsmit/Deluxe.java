package com.codewithsmit;

public class Deluxe extends savings{
    double RegularInterest = 0.15;
    Double Amount,InitialDeposit;
    int noOfYears;

    public Deluxe(String customerName, String typeofSavings, int customerNo, int noOfYears, double initialDeposit) {
        super(customerName, typeofSavings, customerNo, noOfYears, initialDeposit);
        this.noOfYears = noOfYears;
        this.InitialDeposit = initialDeposit;
    }
    public double CalulateCI()
    {
        Amount = Math.pow(InitialDeposit*(1+(RegularInterest/noOfYears)),noOfYears);
        return Amount;

    }


}
