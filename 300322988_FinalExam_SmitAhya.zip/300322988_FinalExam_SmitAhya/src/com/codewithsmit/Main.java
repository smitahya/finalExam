package com.codewithsmit;

import java.sql.SQLException;

public class Main {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        savings j1 = new savings();
        j1.model();
        j1.updatetable();
        j1.setVisible(true);

    }
}
